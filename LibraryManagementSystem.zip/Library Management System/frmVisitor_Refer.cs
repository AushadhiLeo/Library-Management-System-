﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class frmVisitor_Refer : Form
    {
        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        // Dictionary to store book names and their corresponding IDs
        Dictionary<string, string> bookDictionary = new Dictionary<string, string>();


        //-------------------------------------------------------------------------------------------------------------------------------------------------
        public frmVisitor_Refer()
        {
            InitializeComponent();
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Mouse hover colors
        private void btnSearch_MouseEnter(object sender, EventArgs e)
        {
            btnSearch.BackColor = Color.Yellow;
        }

        private void btnSearch_MouseLeave(object sender, EventArgs e)
        {
            btnSearch.BackColor = Color.Gold;   //Search Button
        }

        //*************************************************************************

        private void btnRefresh_MouseEnter(object sender, EventArgs e)
        {
            btnRefresh.BackColor = Color.White;
        }

        private void btnRefresh_MouseLeave(object sender, EventArgs e)
        {
            btnRefresh.BackColor = Color.WhiteSmoke;     //Refresh button
        }

        //*************************************************************************

        private void btnExit_MouseEnter(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Red;
        }

        private void btnExit_MouseLeave(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.FromArgb(192, 0, 0);  //Exit button
        }

        //*************************************************************************

        private void btnReferBook_MouseEnter(object sender, EventArgs e)
        {
            btnReferBook.BackColor = Color.Orange;
        }

        private void btnReferBook_MouseLeave(object sender, EventArgs e)
        {
            btnReferBook.BackColor = Color.DarkOrange;  //Issue Book Button
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();  //Rfresh form
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();   //close the form
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Connect visitor details to textboxes according to visitorId
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text != "")
            {
                string vid = txtSearch.Text;

                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM Visitors WHERE vId = '" + vid + "'", con);   // SQL command to select data from the Visitors table
                SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
                DataSet DS = new DataSet();
                SDA.Fill(DS);

                if (DS.Tables[0].Rows.Count != 0)   //Checks if the table has any data
                {
                    txtVname.Text = DS.Tables[0].Rows[0][1].ToString();
                    txtSex.Text = DS.Tables[0].Rows[0][2].ToString();
                    txtNIC.Text = DS.Tables[0].Rows[0][3].ToString();
                }
                else
                {
                    txtVname.Clear();
                    txtSex.Clear();
                    txtNIC.Clear();

                    MessageBox.Show("Invalid Visitor Id", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);  //Display error message if the visitorId is wrong/ not available                
                }

                con.Close();

            }
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Connect book details to Book ID textbox and combobox
        private void frmVisitor_Refer_Load(object sender, EventArgs e)
        {
            con.Open();


            SqlCommand cmd = new SqlCommand("SELECT bId, bName FROM Books WHERE bstatus = 'Only for Reference'", con);   // SQL command to select book IDs and names from the Books table
            SqlDataReader DR = cmd.ExecuteReader();

            while (DR.Read())   // Read data from the database
            {
                string bookId = DR.GetString(0);
                string bookName = DR.GetString(1);  // Retrieve the book ID and name

                bookDictionary[bookName] = bookId;  // Store book ID and name in the dictionary

                comboBoxBook.Items.Add(bookName);   // Add book name to the combo box
            }
            DR.Close();

            con.Close();

            // Attach the SelectedIndexChanged event handler
            comboBoxBook.SelectedIndexChanged += new EventHandler(comboBoxBook_SelectedIndexChanged);
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        // Get the book ID from the dictionary and set it to the textbox
        private void comboBoxBook_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if an item is selected in the combo box
            if (comboBoxBook.SelectedItem != null)
            {
                string selectedBook = comboBoxBook.SelectedItem.ToString();

                // Check if the dictionary is initialized and contains the selected book
                if (bookDictionary != null && bookDictionary.TryGetValue(selectedBook, out string bookId))
                {
                    txtBId.Text = bookId;   // Display the Book Id
                }
                else
                {
                    // Optionally handle the case where the book is not found in the dictionary
                    txtBId.Text = string.Empty; // Clear the text box or handle accordingly
                }
            }
            else
            {
                // Optionally handle the case where no item is selected
                txtBId.Text = string.Empty; // Clear the text box or handle accordingly
            }
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        private void btnReferBook_Click(object sender, EventArgs e)
        {
            string vid = txtSearch.Text;
            string vname = txtVname.Text;
            string sex = txtSex.Text;
            string nic = txtNIC.Text;
            string bid = txtBId.Text;
            string bname = comboBoxBook.Text;

            con.Open();

            // Check if the user has already issued the same book
            SqlCommand checkSameBookCmd = new SqlCommand("SELECT COUNT(*) FROM Visitor_Refer WHERE VisitorId = '" + vid + "' AND BookId = '" + bid + "'", con);

            int sameBookCount = (int)checkSameBookCmd.ExecuteScalar();

            if (sameBookCount > 0) // Check if the same book is already issued to the user
            {
                MessageBox.Show("This book has already been issued to the visitor!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); // Display error message if the same book is already issued
                return;
            }

            con.Close();

            //********************************************************************************************************************

            con.Open();

            //Checks if have enough copies of books 
            SqlCommand checkCopiesCmd = new SqlCommand("SELECT bCopies FROM Books WHERE bId = '" + bid + "'", con);
            int checkCopies = (int)checkCopiesCmd.ExecuteScalar();

            if (checkCopies <= 0)  //Checks if the book copies count = 0
            {
                MessageBox.Show("Selected book haven't enough copies to refer!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//Display error message if the book count < 5
                return;
            }

            con.Close();

            //********************************************************************************************************************

            con.Open();

            // Insert the new book issuance record
            SqlCommand insertQuery = new SqlCommand("INSERT INTO Visitor_Refer (VisitorId, VisitorName, Sex, NIC, BookId, BookName) VALUES ('" + vid + "', '" + vname + "', '" + sex + "', '" + nic + "', '" + bid + "', '" + bname + "') ", con);
            insertQuery.ExecuteNonQuery();

            MessageBox.Show("Book issued successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            con.Close();

            //********************************************************************************************************************

            con.Open();

            // Update the quantity of the book in the Books table
            SqlCommand updateBookCmd = new SqlCommand("UPDATE Books SET bCopies = bCopies - 1 WHERE bId = '" + bid + "'", con); // decreases the number of available bCopies of the book by 1
            updateBookCmd.ExecuteNonQuery();

            txtSearch.Clear();
            txtVname.Clear();
            txtSex.Clear();
            txtNIC.Clear();
            txtBId.Clear();
            comboBoxBook.SelectedIndex = -1;

            con.Close();
        }

    }
}
