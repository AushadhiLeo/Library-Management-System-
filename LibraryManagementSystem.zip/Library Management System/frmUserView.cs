﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Library_Management_System
{
    public partial class frmUserView : Form
    {
        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();

        //-----------------------------------------------------------------------------------------------------------------------------------------

        public frmUserView()
        {
            InitializeComponent();
        }

        //-----------------------------------------------------------------------------------------------------------------------------------------

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            this.Close();   //Close the form
        }

        //-----------------------------------------------------------------------------------------------------------------------------------------


        //Mouse hover colors
        private void btnUpdate_MouseEnter_1(object sender, EventArgs e)
        {
            btnUpdate.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void btnUpdate_MouseLeave_1(object sender, EventArgs e)
        {
            btnUpdate.BackColor = Color.Green;  //UPDATE button      
        }

        private void btnDelete_MouseEnter_1(object sender, EventArgs e)
        {
            btnDelete.BackColor = Color.FromArgb(192, 0, 0);
        }

        private void btnDelete_MouseLeave_1(object sender, EventArgs e)
        {
            btnDelete.BackColor = Color.Maroon; //DELETE button
        }

        private void btnCancel_MouseEnter_1(object sender, EventArgs e)
        {
            btnCancel.BackColor = Color.Red;
        }

        private void btnCancel_MouseLeave_1(object sender, EventArgs e)
        {
            btnCancel.BackColor = Color.FromArgb(192, 0, 0);    //Cancel button
        }


        //------------------------------------------------------------------------------------------------------------------------------------------


        //View Users table data when form loaded
        private void frmUserView_Load(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Users table 
            cmd.CommandText = "SELECT * FROM Users";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];

            con.Close();
        }

        //-------------------------------------------------------------------------------------------------------------------------------------------


        //Search user by id
        private void txtUserSearch_TextChanged(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT * FROM Users WHERE uId LIKE '" + txtUserSearch.Text + "%' ", con);

            SqlDataAdapter SDA = new SqlDataAdapter();
            DataTable DT = new DataTable();

            SDA.SelectCommand = cmd;
            DT.Clear();
            SDA.Fill(DT);

            dataGridView1.DataSource = DT;

            con.Close();
        }


        //---------------------------------------------------------------------------------------------------------------------------------------


        //Assigning table data into textboxes to display when click a table cell

        string uid;  // Variable to store the user ID

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)    // Check if the clicked cell has a value
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                uid = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();    // If there is a value, retrieve the user ID from the clicked row 
            }

            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Users table based on the retrieved user ID
            cmd.CommandText = "SELECT * FROM Users WHERE uId = '" + uid + "'";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];    // Bind the dataset to the dataGridView1 for display 

            txtUserID.Text = DS.Tables[0].Rows[0][0].ToString();
            txtUserName.Text = DS.Tables[0].Rows[0][1].ToString();
            comboBoxSex.Text = DS.Tables[0].Rows[0][2].ToString();  // Populate textboxes with data from the dataset
            txtNIC.Text = DS.Tables[0].Rows[0][3].ToString();
            txtAdress.Text = DS.Tables[0].Rows[0][4].ToString();

            con.Close();
        }


        //----------------------------------------------------------------------------------------------------------------------------------------------


        //Update data
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            String uname = txtUserName.Text;
            String usex = comboBoxSex.Text;
            String nic = txtNIC.Text;
            String address = txtAdress.Text;


            if(MessageBox.Show("Data will be updated. Are you sure?","Attention",MessageBoxButtons.OKCancel,MessageBoxIcon.Information) == DialogResult.OK)
            {
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                // Set the command text to update data from the Users table based on the retrieved user ID
                cmd.CommandText = "UPDATE Users SET uName = '" + uname + "', uSex = '" + usex + "', uNIC = '" + nic + "', uAddress = '" + address + "' WHERE uId = '" + uid + "'";
                SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
                DataSet DS = new DataSet();
                SDA.Fill(DS);

                con.Close();

                MessageBox.Show("Data updated successfully!");

                txtUserID.Clear();
                txtUserName.Clear();
                comboBoxSex.SelectedIndex = -1;
                txtNIC.Clear();
                txtAdress.Clear();
            }            
        }


        //----------------------------------------------------------------------------------------------------------------------------------------

        //Refresh
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            frmUserView_Load(this, null);   //Refresh form
        }

        //----------------------------------------------------------------------------------------------------------------------------------------


        //Delete data
        private void btnDelete_Click(object sender, EventArgs e)
        {
            String uname = txtUserName.Text;
            String usex = comboBoxSex.Text;
            String nic = txtNIC.Text;
            String address = txtAdress.Text;


            if (MessageBox.Show("Data will deleted. Are you sure?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                // Set the command text to update data from the Users table based on the retrieved user ID
                cmd.CommandText = "DELETE FROM Users WHERE uId = '" + uid + "'";
                SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
                DataSet DS = new DataSet();
                SDA.Fill(DS);

                con.Close();

                frmUserView_Load(this, null);

                MessageBox.Show("Data deleted successfully!");

                txtUserID.Clear();
                txtUserName.Clear();
                comboBoxSex.SelectedIndex = -1;
                txtNIC.Clear();
                txtAdress.Clear();
            }
        }
    }
}
