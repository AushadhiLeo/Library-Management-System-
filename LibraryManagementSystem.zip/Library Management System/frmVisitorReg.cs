﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Contexts;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class frmVisitorReg : Form
    {

        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();

        //-------------------------------------------------------------------------------------------------------------------------------------------------

        public frmVisitorReg()
        {
            InitializeComponent();
            visitorId();
        }

        //-------------------------------------------------------------------------------------------------------------------------------------------------


        //Mouse hover colors
        private void btnAdd_MouseEnter(object sender, EventArgs e)
        {
            btnAdd.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void btnAdd_MouseLeave(object sender, EventArgs e)  //ADD VISITOR button
        {
            btnAdd.BackColor = Color.Green;
        }

        private void btnExit_MouseEnter(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Red;
        }

        private void btnExit_MouseLeave(object sender, EventArgs e) //Exit button
        {
            btnExit.BackColor = Color.FromArgb(192, 0, 0);
        }

        //---------------------------------------------------------------------------------------------------------------------------------------

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();   //Close the form
        }


        //----------------------------------------------------------------------------------------------------------------------------------------


        //Generate Visitor Id
        SqlCommand cmd;
        SqlDataAdapter da;  // Define class-level variables for SQL operations
        SqlDataReader dr;
        string sql;

        public void visitorId()    // Method to generate a new visitor ID
        {
            try
            {
                sql = "SELECT MAX(vId) FROM Visitors";  // get the maximum visitor ID from the Users table
                cmd = new SqlCommand(sql, con); // Initialize the SqlCommand with the query and connection

                con.Open();

                var maxid = cmd.ExecuteScalar() as string;  // Execute the query and get the result as a string

                if (maxid == null)  // Check if the result is null
                {
                    txtVisitorID.Text = "V0001";    // If no records, set the visitor ID to the starting value "V0001"
                }
                else
                {
                    int intval = int.Parse(maxid.Substring(1, 4));  // Extract the numeric part from the max ID ( "V0001" -> 1)
                    intval++;   // Increment the numeric part by 1
                    txtVisitorID.Text = String.Format("V{0:0000}", intval);     // Format the new user ID with a leading "U" and padded zeros
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);    // Display any exceptions that occur in a message box
            }


        }


        //---------------------------------------------------------------------------------------------------------------------------------------------


        //Add new visitor
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string vid = txtVisitorID.Text;
            string vname = txtVisitorName.Text;
            string sex = comboBoxSex.Text;
            string nic = txtNIC.Text;

            con.Open();

            // Insert Query - Insert data into columns from Visitors table
            SqlCommand cmd = new SqlCommand("INSERT INTO Visitors(vId, vName, vSex, vNIC) VALUES ('" + vid + "', '" + vname + "','" + sex + "','" + nic + "')", con);
            cmd.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("New visitor added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            visitorId();   // Call the visitorId() function to generate a new visitor ID

            // Clear the textboxes and reset the combo box after successful insertion
            txtVisitorName.Clear();
            comboBoxSex.SelectedIndex = -1; // Reset to default value
            txtNIC.Clear();
        }
    }
}
