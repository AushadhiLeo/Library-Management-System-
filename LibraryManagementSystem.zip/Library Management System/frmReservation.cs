﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Library_Management_System
{
    public partial class frmReservation : Form
    {
        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();

        //-------------------------------------------------------------------------------------------------------------------------------------------------


        // Dictionary to store book names and their corresponding IDs
        Dictionary<string, string> bookDictionary = new Dictionary<string, string>();


        //-------------------------------------------------------------------------------------------------------------------------------------------------


        public frmReservation()
        {
            InitializeComponent();
            reserveId();
        }

        //----------------------------------------------------------------------------------------------------------------------------------------


        //Mouse hover colors
        private void btnAdd_MouseEnter(object sender, EventArgs e)
        {
            btnAdd.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void btnAdd_MouseLeave(object sender, EventArgs e)
        {
            btnAdd.BackColor = Color.Green; //Add button
        }

        //**********************************************************************************************

        private void btnExit_MouseEnter(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Red;
        }

        private void btnExit_MouseLeave(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.FromArgb(192, 0, 0);  //Exit button
        }

        //----------------------------------------------------------------------------------------------------------------------------------------


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();   //Close the form
        }


        //----------------------------------------------------------------------------------------------------------------------------------------


        
        //Generate the reserveId
        SqlCommand cmd;
        SqlDataAdapter da;  // Define class-level variables for SQL operations
        SqlDataReader dr;
        string sql;

        public void reserveId() // Method to generate a new reserve ID
        {

            try
            {
                sql = "SELECT MAX(ReserveId) FROM Reservations";    // get the maximum user ID from the reserve table
                cmd = new SqlCommand(sql, con); // Initialize the SqlCommand with the query and connection

                con.Open();

                var maxid = cmd.ExecuteScalar() as string;  // Execute the query and get the result as a string

                if (maxid == null)  // Check if the result is null
                {
                    txtRid.Text = "RE0001"; // If no records, set the user ID to the starting value "RE0001"
                }
                else
                {
                    int intval = int.Parse(maxid.Substring(2, 4));  // Extract the numeric part from the max ID ( "RE0001" -> 1)
                    intval++;   // Increment the numeric part by 1
                    txtRid.Text = String.Format("RE{0:0000}", intval);  // Format the new user ID with a leading "RE" and padded zeros
                }

                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);    // Display any exceptions that occur in a message box
            }

        }


        //----------------------------------------------------------------------------------------------------------------------------------------


        //Add new reservation
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string rid = txtRid.Text;
            string uid = txtUid.Text;
            string bid = txtBid.Text;
            string bname = comboBoxBName.Text;
            string date = dateTimePicker1.Text;
            string status = comboBoxStatus.Text;

            try
            {
                using (con)
                {
                    con.Open();

                    // Check if the user has already reserved the same book
                    SqlCommand checkSameBookCmd = new SqlCommand("SELECT COUNT(*) FROM Reservations WHERE UserId = '" + uid + "' AND BookId = '" + bid + "'", con);

                    int sameBookCount = (int)checkSameBookCmd.ExecuteScalar();

                    if (sameBookCount > 0) // Check if the same book is already reserved to the user
                    {
                        MessageBox.Show("This book has already been reserved to the user!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); // Display error message if the same book is already reserved
                        return;
                    }


                    //********************************************************************************************************************

                    // Insert the new book reservation record
                    SqlCommand cmd = new SqlCommand("INSERT INTO Reservations (ReserveId, UserId, BookId, BookName, ReserveDate, Status) VALUES ('" + rid + "', '" + uid + "', '" + bid + "', '" + bname + "', '" + date + "', '" + status + "')", con);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Book reserved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    reserveId();    // Call the reserveId() function to generate a new reserveId

                    txtBid.Clear();
                    txtUid.Clear();
                    comboBoxBName.SelectedIndex = -1;   // Reset to default value
                    dateTimePicker1.ResetText();
                    comboBoxStatus.SelectedIndex = -1;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }            
        }


        //----------------------------------------------------------------------------------------------------------------------------------------


        private void frmReservation_Load(object sender, EventArgs e)
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT bId, bName FROM Books WHERE bStatus = 'Borrowable'", con);   // SQL command to select book IDs and names from the Books table)
            SqlDataReader DR = cmd.ExecuteReader();

            while (DR.Read())   // Read data from the database
            {
                string bookId = DR.GetString(0);
                string bookName = DR.GetString(1);  // Retrieve the book ID and name

                bookDictionary[bookName] = bookId;  // Store book ID and name in the dictionary

                comboBoxBName.Items.Add(bookName);   // Add book name to the combo box
            }
            DR.Close();

            con.Close();

            // Attach the SelectedIndexChanged event handler
            comboBoxBName.SelectedIndexChanged += new EventHandler(comboBoxBName_SelectedIndexChanged);

        }


        //----------------------------------------------------------------------------------------------------------------------------------------



        // Get the book ID from the dictionary and set it to the textbox
        private void comboBoxBName_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if an item is selected in the combo box
            if (comboBoxBName.SelectedItem != null)
            {
                string selectedBook = comboBoxBName.SelectedItem.ToString();

                // Check if the dictionary is initialized and contains the selected book
                if (bookDictionary != null && bookDictionary.TryGetValue(selectedBook, out string bookId))
                {
                    txtBid.Text = bookId;   // Display the Book Id
                }
                else
                {
                    // Optionally handle the case where the book is not found in the dictionary
                    txtBid.Text = string.Empty; // Clear the text box or handle accordingly
                }
            }
            else
            {
                // Optionally handle the case where no item is selected
                txtBid.Text = string.Empty; // Clear the text box or handle accordingly
            }
        }
    }
    
}
