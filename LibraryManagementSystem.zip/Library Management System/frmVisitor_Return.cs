﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class frmVisitor_Return : Form
    {
        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------


        public frmVisitor_Return()
        {
            InitializeComponent();
        }

        //---------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Mouse hover colors
        private void btnSearch_MouseEnter(object sender, EventArgs e)
        {
            btnSearch.BackColor = Color.Yellow;
        }

        private void btnSearch_MouseLeave(object sender, EventArgs e)
        {
            btnSearch.BackColor = Color.Gold;   //Search Button
        }

        //*************************************************************************************************************

        private void btnRefresh_MouseEnter(object sender, EventArgs e)
        {
            btnRefresh.BackColor = Color.White;
        }

        private void btnRefresh_MouseLeave(object sender, EventArgs e)
        {
            btnRefresh.BackColor = Color.WhiteSmoke;     //Refresh button
        }

        //*************************************************************************************************************

        private void btnExit_MouseEnter(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Red;
        }

        private void btnExit_MouseLeave(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.FromArgb(192, 0, 0);  //Exit button
        }

        //*************************************************************************************************************

        private void btnReturn_MouseEnter(object sender, EventArgs e)
        {
            btnReturn.BackColor = Color.Orange;
        }

        private void btnReturn_MouseLeave(object sender, EventArgs e)
        {
            btnReturn.BackColor = Color.DarkOrange;  //Return Book Button
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();   //Close the form
        }

        //---------------------------------------------------------------------------------------------------------------------------------------------------------------


        //View Visitor_Refer table data when form loaded
        private void frmVisitor_Return_Load(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Users table 
            cmd.CommandText = "SELECT * FROM Visitor_Refer";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];

            con.Close();
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Refresh
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            frmVisitor_Return_Load(this, null);
            txtSearch.Clear();
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Search visitor details
        private void btnSearch_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT VisitorId, VisitorName, BookId, BookName FROM Visitor_Refer WHERE VisitorId = '" + txtSearch.Text + "'", con);
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];

            con.Close();
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------



        //Assigning table data into textboxes to display when click a table cell

        string vid;  // Variable to store the visitor ID

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                vid = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();    // If there is a value, retrieve the visitor ID from the clicked row 
            }

            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Visitor_Refe table based on the retrieved visitor ID
            cmd.CommandText = "SELECT BookId, BookName FROM Visitor_Refer WHERE VisitorId = '" + vid + "'";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];    // Bind the dataset to the dataGridView1 for display 

            txtBookId.Text = DS.Tables[0].Rows[0][0].ToString();
            txtBookName.Text = DS.Tables[0].Rows[0][1].ToString();

            con.Close();
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Return book
        private void btnReturn_Click(object sender, EventArgs e)
        {
            string vid = txtSearch.Text;
            string bid = txtBookId.Text;

            con.Open();

            // Delete the record from Issue_Books
            SqlCommand deleteIssueCmd = new SqlCommand("DELETE FROM Visitor_Refer WHERE VisitorId = '" + vid + "'", con);
            deleteIssueCmd.ExecuteNonQuery();

            con.Close();


            //********************************************************************************************************************

            con.Open();

            // Update the quantity of the book in the Books table
            SqlCommand updateBookCmd = new SqlCommand("UPDATE Books SET bCopies = bCopies + 1 WHERE bId = '" + bid + "'", con); // Increases the number of available bCopies of the book by 1
            updateBookCmd.ExecuteNonQuery();

            con.Close();

            //********************************************************************************************************************

            frmVisitor_Return_Load(this, null);

        }
    }
}
