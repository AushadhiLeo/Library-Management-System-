﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace Library_Management_System
{
    public partial class frmReservation_Info : Form
    {

        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();

        //-------------------------------------------------------------------------------------------------------------------------------------------------


        public frmReservation_Info()
        {
            InitializeComponent();
        }

        //-------------------------------------------------------------------------------------------------------------------------------------------------

        //mouse hover colors
        private void btnRefresh_MouseEnter(object sender, EventArgs e)
        {
            btnRefresh.BackColor = Color.White;
        }

        private void btnRefresh_MouseLeave(object sender, EventArgs e)
        {
            btnRefresh.BackColor = Color.WhiteSmoke;    //Refresh button
        }

        //**********************************************************************************

        private void btnNotify_MouseEnter(object sender, EventArgs e)
        {
            btnNotify.BackColor = Color.Orange;
        }

        private void btnNotify_MouseLeave(object sender, EventArgs e)
        {
            btnNotify.BackColor = Color.DarkOrange; //notify button
        }

        //**********************************************************************************

        private void btnExit_MouseEnter(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Red;
        }

        private void btnExit_MouseLeave(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.FromArgb(192, 0, 0);  //exit button
        }
        //-------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();   //Close the form
        }

        //-------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void frmReservation_Info_Load(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Books table 
            cmd.CommandText = "SELECT * FROM Reservations WHERE Status = 'Pending' ORDER BY ReserveDate ASC";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];

            con.Close();
        }






        private void ExecuteNonQuery(string query, params SqlParameter[] parameters)
        {
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddRange(parameters);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Assigning table data into textboxes to display when click a table cell
        string rid;

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                rid = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();  // If there is a value, retrieve the reservation ID from the clicked row
                //MessageBox.Show(rid);
            }

            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Books table based on the retrieved book ID
            cmd.CommandText = "SELECT ReserveId, UserId, BookId, BookName, ReserveDate FROM Reservations WHERE ReserveId = '" + rid + "'";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            txtRid.Text = DS.Tables[0].Rows[0][0].ToString();
            txtUid.Text = DS.Tables[0].Rows[0][1].ToString();
            txtBid.Text = DS.Tables[0].Rows[0][2].ToString();
            txtBname.Text = DS.Tables[0].Rows[0][3].ToString(); // Populate textboxes with data from the dataset
            txtDate.Text = DS.Tables[0].Rows[0][4].ToString();
            con.Close();
        }


        //-------------------------------------------------------------------------------------------------------------------------------------------------------------


        private void btnNotify_Click(object sender, EventArgs e)
        {
            string uid = txtUid.Text;

            MessageBox.Show($"Book is now available. Notifying {uid} for pick up.","Information",MessageBoxButtons.OK, MessageBoxIcon.Information);

            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Books table based on the retrieved book ID
            cmd.CommandText = "SELECT ReserveId, UserId, BookId, BookName, ReserveDate FROM Reservations WHERE ReserveId = '" + rid + "'";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);
            con.Close();

            txtRid.Clear();
            txtUid.Clear();
            txtBid.Clear();
            txtBname.Clear();
            txtDate.Clear();

            //****************************************************************************************

            con.Open();

                SqlCommand cmd1 = new SqlCommand();
                cmd1.Connection = con;

                // Set the command text to update data from the Books table based on the retrieved book ID
                cmd1.CommandText = "DELETE FROM Reservations WHERE ReserveId = '" + rid + "'";
                SqlDataAdapter SDA1 = new SqlDataAdapter(cmd1);   // Create a data adapter to execute the command and fill the dataset
                DataSet DS1 = new DataSet();
                SDA1.Fill(DS1);

            con.Close();

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand cmd2 = new SqlCommand();
            cmd2.Connection = con;

            cmd2.CommandText = "SELECT * FROM Reservations WHERE Status = 'Pending' ORDER BY ReserveDate ASC";
            SqlDataAdapter SDA2 = new SqlDataAdapter(cmd2);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS2 = new DataSet();
            SDA2.Fill(DS2);

            dataGridView1.DataSource = DS2.Tables[0];

            con.Close();
        }
    }
}
