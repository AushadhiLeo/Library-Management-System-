﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class frmDashboard : Form
    {
        public frmDashboard()
        {
            InitializeComponent();
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Displaying forms
        private void addNewBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBookReg frmBookReg = new frmBookReg();
            frmBookReg.Show();  //Display book reg. form
        }

        //*************************************************************************************************************

        private void viewBookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBookView frmBookView = new frmBookView();
            frmBookView.Show(); //Display book view form
        }

        //*************************************************************************************************************
               
        private void addNewUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUserReg frmUserReg = new frmUserReg();
            frmUserReg.Show();  //Display user reg. form
        }


        //*************************************************************************************************************
        private void viewUserInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUserView frmUserView = new frmUserView();
            frmUserView.Show(); //Display user view form
        }

        //*************************************************************************************************************

        private void registerNewVisitorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVisitorReg frmVisitorReg = new frmVisitorReg();
            frmVisitorReg.Show();   //Display visitor reg. form
        }

        //*************************************************************************************************************

        private void viewVisitorInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVisitorView frmVisitorView = new frmVisitorView();   
            frmVisitorView.Show();  //Display visitor view form
        }

        //*************************************************************************************************************
        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReservation frmReservation = new frmReservation();
            frmReservation.Show();  //Display reservation form
        }

        //*************************************************************************************************************

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        //*************************************************************************************************************

        private void usersToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmIssueBook frmIssues = new frmIssueBook();
            frmIssues.Show();   //Display issue book
        }

        //*************************************************************************************************************

        private void visitorsToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmVisitor_Return frmVisitorReturn = new frmVisitor_Return();
            frmVisitorReturn.Show();    //Display visitor return form
        }

        //*************************************************************************************************************

        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIssueBook frmIssueBook = new frmIssueBook();
            frmIssueBook.Show();    //Display issue book form
        }

        //*************************************************************************************************************

        private void visitorsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmVisitor_Refer frmVisitor_Refer = new frmVisitor_Refer();
            frmVisitor_Refer.Show();    //Display visitor refer form
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit(); //Close the form
        }

       
    }
}
