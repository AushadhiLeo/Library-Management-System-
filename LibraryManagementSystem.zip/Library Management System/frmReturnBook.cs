﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Contexts;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Library_Management_System
{
    public partial class frmReturnBook : Form
    {
        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------


        public frmReturnBook()
        {
            InitializeComponent();
        }

        //Mouse hover colors
        private void btnSearch_MouseEnter(object sender, EventArgs e)
        {
            btnSearch.BackColor = Color.Yellow;
        }

        private void btnSearch_MouseLeave(object sender, EventArgs e)
        {
            btnSearch.BackColor = Color.Gold;   //Search Button
        }

        private void btnRefresh_MouseEnter(object sender, EventArgs e)
        {
            btnRefresh.BackColor = Color.White;
        }

        private void btnRefresh_MouseLeave(object sender, EventArgs e)
        {
            btnRefresh.BackColor = Color.WhiteSmoke;     //Refresh button
        }

        private void btnExit_MouseEnter(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Red;
        }

        private void btnExit_MouseLeave(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.FromArgb(192, 0, 0);  //Exit button
        }       

        private void btnReturn_MouseEnter(object sender, EventArgs e)
        {
            btnReturn.BackColor = Color.Orange;
        }

        private void btnReturn_MouseLeave(object sender, EventArgs e)
        {
            btnReturn.BackColor = Color.DarkOrange;  //Return Book Button
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------------------------


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); //Close the form
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        //View Issue_Books table data when form loaded
        private void frmReturnBook_Load(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Issue_Books table 
            cmd.CommandText = "SELECT * FROM Issue_Books";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];

            con.Close();
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Refresh
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            frmReturnBook_Load(this, null);
            txtSearch.Clear();
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Search user details
        private void btnSearch_Click(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT UserId, UserName, BookId, BookName, IssueDate, DueDate FROM Issue_Books WHERE UserId = '" + txtSearch.Text +"'", con);
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

           dataGridView1.DataSource = DS.Tables[0];

            con.Close();
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------



        //Assigning table data into textboxes to display when click a table cell

        string uid;  // Variable to store the user ID

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                uid = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();    // If there is a value, retrieve the user ID from the clicked row 
            }

            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Return_Books table based on the retrieved user ID
            cmd.CommandText = "SELECT UserId, UserName, BookId, BookName, IssueDate, DueDate FROM Issue_Books WHERE UserId = '" + uid + "'";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];    // Bind the dataset to the dataGridView1 for display 

            txtBookId.Text = DS.Tables[0].Rows[0][2].ToString();
            txtBookName.Text = DS.Tables[0].Rows[0][3].ToString();
            dateTimePickerIssue.Text = DS.Tables[0].Rows[0][4].ToString();
            dateTimePickerReturn.Text = DS.Tables[0].Rows[0][5].ToString();

            con.Close();
        }



        //--------------------------------------------------------------------------------------------------------------------------------------------------------------


        //Return book
        private void btnReturn_Click(object sender, EventArgs e)
        {
            string uid = txtSearch.Text;
            string bid = txtBookId.Text;
            string name = txtBookName.Text;
            string issue = dateTimePickerIssue.Text;
            string returndate = dateTimePickerReturn.Text;

            con.Open();

            // Insert the new book issuance record
            SqlCommand insertQuery = new SqlCommand("INSERT INTO Return_Books (UserId, BookId, BookName, IssueDate, ReturnDate) VALUES ('" + uid + "', '" + bid + "', '" + name +"', '" + issue + "', '" + returndate + "') ", con);
            insertQuery.ExecuteNonQuery();
            MessageBox.Show("Book returned successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtSearch.Clear();
            txtBookId.Clear();
            txtBookName.Clear();
            dateTimePickerIssue.ResetText();
            dateTimePickerReturn.ResetText();

            con.Close();

            //********************************************************************************************************************

            con.Open();

            // Delete the record from Issue_Books
            SqlCommand deleteIssueCmd = new SqlCommand("DELETE FROM Issue_Books WHERE UserId = '" + uid +"'", con);
            deleteIssueCmd.ExecuteNonQuery();

            con.Close();

            //********************************************************************************************************************

            con.Open();

            // Update the quantity of the book in the Books table
            SqlCommand updateBookCmd = new SqlCommand("UPDATE Books SET bCopies = bCopies + 1 WHERE bId = '" + bid + "'", con); // Increases the number of available bCopies of the book by 1
            updateBookCmd.ExecuteNonQuery();

            con.Close();

            //********************************************************************************************************************

            frmReturnBook_Load(this, null);

        }
    }
}
