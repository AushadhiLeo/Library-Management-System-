﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Text;

namespace Library_Management_System
{
    public partial class frmBookReg : Form
    {

        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();

        //----------------------------------------------------------------------------------------------------------------------------------------


        public frmBookReg()
        {
            InitializeComponent();
        }

        //----------------------------------------------------------------------------------------------------------------------------------------


        //Mouse hover colors
        private void btnGenerate_MouseEnter(object sender, EventArgs e)
        {
            btnGenerate.BackColor = Color.FromArgb(255, 255, 128);
        }

        private void btnGenerate_MouseLeave(object sender, EventArgs e) //Generate ID button
        {
            btnGenerate.BackColor = Color.Yellow;
        }

        //**********************************************************************************************

        private void btnAdd_MouseEnter(object sender, EventArgs e)
        {
            btnAdd.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void btnAdd_MouseLeave(object sender, EventArgs e)  //Add button
        {
            btnAdd.BackColor = Color.Green;
        }

        //**********************************************************************************************

        private void btnExit_MouseEnter(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Red;
        }

        private void btnExit_MouseLeave(object sender, EventArgs e) //Exit button
        {
            btnExit.BackColor = Color.FromArgb(192, 0, 0);
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close(); //Close the form
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------



        //Generate BookId according to its classification
        SqlCommand cmd;
        SqlDataAdapter da; 
        SqlDataReader dr;
        string sql;

        private Dictionary<string, int> classificationCounts = new Dictionary<string, int>();   // Dictionary to keep track of the last ID no. for each classification

        public void GenerateBookID()    // Method to generate a new book ID
        {
            try
            {                
                if (comboBoxClass.SelectedItem == null) // Ensure a classification is selected in the ComboBox
                {
                    MessageBox.Show("Please select a Classification", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                
                string classification = comboBoxClass.SelectedItem.ToString().Trim();   // Get the selected classification from the ComboBox

                if (string.IsNullOrEmpty(classification))
                {
                    MessageBox.Show("Please enter a Classification", "Reminder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                               
                string prefix = classification.Substring(0, 1).ToUpper();    // Get the prefix from the first letter of the classification, converted to uppercase

                sql = $"SELECT MAX(bId) FROM Books WHERE bId LIKE '{prefix}%'";  // get the maximum book ID with the same prefix from the Books table
                cmd = new SqlCommand(sql, con);

                con.Open();

                var maxid = cmd.ExecuteScalar() as string;  // Execute the query and get the result as a string

                if (maxid == null)  // Check if the result is null
                {
                    txtBookID.Text = $"{prefix}0001";    // If no records, set the book ID to the starting value with the prefix and "0001"
                }
                else
                {
                    int intval = int.Parse(maxid.Substring(1, 4));  // Extract the numeric part from the max ID ( "X0001" -> 1)
                    intval++;   // Increment the numeric part by 1
                    txtBookID.Text = String.Format("{0}{1:0000}", prefix, intval);  // Format the new book ID with the prefix and padded zeros
                }
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);    // Display any exceptions that occur in a message box

                con.Close(); // Ensure the connection is closed in case of an exception
            }
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            GenerateBookID();   //To display BookId
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------


        //Add new book
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string bid = txtBookID.Text;
            string bname = txtBookName.Text;
            string bauthor = txtAuthor.Text;
            string bpublisher = txtPublisher.Text;
            string bclassification = comboBoxClass.Text;
            Int64 copies = Int64.Parse(txtCopies.Text);
            string status = comboBoxStatus.Text;

            con.Open();

            //Insert Query - Insert data into columns from Books table
            SqlCommand cmd = new SqlCommand("INSERT INTO Books (bId, bName, bAuthor, bPublisher, bClassification, bCopies, bStatus) VALUES ('" + bid + "','" + bname + "','" + bauthor + "','" + bpublisher + "','" + bclassification + "'," + copies + ",'" + status + "')", con);
            cmd.ExecuteNonQuery();


            if(int.TryParse(txtCopies.Text, out int value) && value > 10)  //Check if the book copies are => 10
            {
                MessageBox.Show("Only 10 copies can enter at once!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show("New book added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            con.Close();

            // Clear the textboxes and reset the combo box after successful insertion
            txtBookID.Clear();
            txtBookName.Clear();
            txtAuthor.Clear();
            txtPublisher.Clear();
            comboBoxClass.SelectedIndex = -1; // Reset to default value
            txtCopies.Clear();
            comboBoxStatus.SelectedIndex = -1;
        }

    }

}
