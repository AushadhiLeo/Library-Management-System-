﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Contexts;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class frmVisitorView : Form
    {
        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();

        //-----------------------------------------------------------------------------------------------------------------------------------------

        public frmVisitorView()
        {
            InitializeComponent();
        }

        //--------------------------------------------------------------------------------------------------------------------------------------

        //Mouse hover colors
        private void btnUpdate_MouseEnter(object sender, EventArgs e)
        {
            btnUpdate.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void btnUpdate_MouseLeave(object sender, EventArgs e)
        {
            btnUpdate.BackColor = Color.Green; //Update button
        }

        private void btnDelete_MouseEnter(object sender, EventArgs e)
        {
            btnDelete.BackColor = Color.FromArgb(192, 0, 0);
        }

        private void btnDelete_MouseLeave(object sender, EventArgs e)
        {
            btnDelete.BackColor = Color.Maroon; //Delete button
        }

        private void btnCancel_MouseEnter(object sender, EventArgs e)
        {
            btnCancel.BackColor = Color.Red;
        }

        private void btnCancel_MouseLeave(object sender, EventArgs e)
        {
            btnCancel.BackColor = Color.FromArgb(192, 0, 0);    //Cancel button
        }

        
        //------------------------------------------------------------------------------------------------------------------------------------------

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();   //Close the form
        }

        //-----------------------------------------------------------------------------------------------------------------------------------------


        //View Visitors table data when form loaded
        private void frmVisitorView_Load(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Visitors table 
            cmd.CommandText = "SELECT * FROM Visitors";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];

            con.Close();
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------

        //Assigning table data into textboxes to display when click a table cell

        string vid;  // Variable to store the visitor ID

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                vid = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();    // If there is a value, retrieve the visitor ID from the clicked row 
                //MessageBox.Show(vid);
            }

            con.Open();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Visitors table based on the retrieved visitor ID
            cmd.CommandText = "SELECT * FROM Visitors WHERE vId = '" + vid + "'";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];    // Bind the dataset to the dataGridView1 for display

            txtVisitorID.Text = DS.Tables[0].Rows[0][0].ToString();
            txtVisitorName.Text = DS.Tables[0].Rows[0][1].ToString();
            comboBoxSex.Text = DS.Tables[0].Rows[0][2].ToString();  // Populate textboxes with data from the dataset
            txtNIC.Text = DS.Tables[0].Rows[0][3].ToString();

            con.Close();

        }


        //---------------------------------------------------------------------------------------------------------------------------------------


        //Search Visitor by id
        private void txtVisitor_TextChanged(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT * FROM Visitors WHERE uId LIKE '" + txtVisitor.Text + "%' ", con);

            SqlDataAdapter SDA = new SqlDataAdapter();
            DataTable DT = new DataTable();

            SDA.SelectCommand = cmd;
            DT.Clear();
            SDA.Fill(DT);

            dataGridView1.DataSource = DT;

            con.Close();
        }


        //----------------------------------------------------------------------------------------------------------------------------------------


        //Refresh data
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            frmVisitorView_Load(this, null);
        }


        //----------------------------------------------------------------------------------------------------------------------------------------


        //Update data
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string vid = txtVisitorID.Text;
            string name = txtVisitorName.Text;
            string sex = comboBoxSex.Text;
            string nic = txtNIC.Text;

            if (MessageBox.Show("Data will be updated. Are you sure?", "Attention", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
            {
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                // Set the command text to update data from the Users table based on the retrieved user ID
                cmd.CommandText = "UPDATE Visitors SET vName = '" + name + "', vSex = '" + sex + "', vNIC = '" + nic + "' WHERE vId = '" + vid + "'";
                SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
                DataSet DS = new DataSet();
                SDA.Fill(DS);

                con.Close();

                frmVisitorView_Load(this, null);

                MessageBox.Show("Data updated successfully!");

                txtVisitorID.Clear();
                txtVisitorName.Clear();
                comboBoxSex.SelectedIndex = -1;
                txtNIC.Clear();
            }
        }


        //------------------------------------------------------------------------------------------------------------------------------------------------


        //Delete data
        private void btnDelete_Click(object sender, EventArgs e)
        {
            string vid = txtVisitorID.Text;
            string name = txtVisitorName.Text;
            string sex = comboBoxSex.Text;
            string nic = txtNIC.Text;

            if (MessageBox.Show("Data will be deleted. Are you sure?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                // Set the command text to update data from the Users table based on the retrieved user ID
                cmd.CommandText = "DELETE FROM Visitors WHERE vId = '" + vid + "'";
                SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
                DataSet DS = new DataSet();
                SDA.Fill(DS);

                con.Close();

                frmVisitorView_Load(this, null);

                MessageBox.Show("Data deleted successfully!");

                txtVisitorID.Clear();
                txtVisitorName.Clear();
                comboBoxSex.SelectedIndex = -1;
                txtNIC.Clear();
            }
        }
    }
}
