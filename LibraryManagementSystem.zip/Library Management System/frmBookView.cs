﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class frmBookView : Form
    {
        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();


        //------------------------------------------------------------------------------------------------------------------------------------------


        public frmBookView()
        {
            InitializeComponent();
        }

        //-------------------------------------------------------------------------------------------------------------------------------------------

        //Mouse hover effect
        private void btnUpdate_MouseEnter(object sender, EventArgs e)
        {
            btnUpdate.BackColor = Color.FromArgb(0, 192, 0);
        }        
        private void btnUpdate_MouseLeave_1(object sender, EventArgs e) //UPDATE button
        {
            btnUpdate.BackColor = Color.Green;
        }

        //*************************************************************************************************

        private void btnRefresh_MouseEnter(object sender, EventArgs e)
        {
            btnRefresh.BackColor = Color.White;
        }

        private void btnRefresh_MouseLeave(object sender, EventArgs e)   //Refresh button
        {
            btnRefresh.BackColor = Color.WhiteSmoke;
        }


        //*************************************************************************************************

        private void btnDelete_MouseEnter(object sender, EventArgs e)
        {
            btnDelete.BackColor = Color.Firebrick;
        }

        private void btnDelete_MouseLeave(object sender, EventArgs e)    //DELETE button
        {
            btnDelete.BackColor= Color.Maroon;
        }

        //*************************************************************************************************

        private void btnCancel_MouseEnter(object sender, EventArgs e)
        {
            btnCancel.BackColor = Color.Red;
        }

        private void btnCancel_MouseLeave(object sender, EventArgs e)    //Cancel button
        {
            btnCancel.BackColor= Color.FromArgb(192, 0, 0);
        }


        //------------------------------------------------------------------------------------------------------------------------------------------

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();   //Close the form
        }


        //------------------------------------------------------------------------------------------------------------------------------------------


        //View Books table data when form loaded
        private void frmBookView_Load(object sender, EventArgs e)
        {
            con.Open();                             
            SqlCommand cmd = new SqlCommand();
            cmd .Connection = con;

            // Set the command text to select data from the Books table 
            cmd.CommandText = "SELECT * FROM Books";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            dataGridView1.DataSource = DS.Tables[0];

            con.Close();
        }


        //------------------------------------------------------------------------------------------------------------------------------------------


        //Assigning table data into textboxes to display when click a table cell
        string bid;

        private void dataGridViewBookInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                bid = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();  // If there is a value, retrieve the book ID from the clicked row
                //MessageBox.Show(bid);
            }

            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            // Set the command text to select data from the Books table based on the retrieved book ID
            cmd.CommandText = "SELECT * FROM Books WHERE bId = '" + bid + "'";
            SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
            DataSet DS = new DataSet();
            SDA.Fill(DS);

            txtBookId.Text = DS.Tables[0].Rows[0][0].ToString();
            txtBook.Text = DS.Tables[0].Rows[0][1].ToString();
            txtAuthor.Text = DS.Tables[0].Rows[0][2].ToString();
            txtPublisher.Text = DS.Tables[0].Rows[0][3].ToString(); // Populate textboxes with data from the dataset
            comboBoxClass.Text = DS.Tables[0].Rows[0][4].ToString();
            txtCopies.Text = DS.Tables[0].Rows[0][5].ToString();
            comboBoxStatus.Text = DS.Tables[0].Rows[0][6].ToString();
            con.Close();
        }
        
        
        //---------------------------------------------------------------------------------------------------------------------------------------------

        
        //Search book by Name's first letter
        private void txtBookSearch_TextChanged(object sender, EventArgs e)
        {
            con.Open();

            SqlCommand cmd = new SqlCommand("SELECT * FROM Books WHERE bName LIKE '" + txtBookSearch.Text + "%' ", con);

            SqlDataAdapter SDA = new SqlDataAdapter();
            DataTable DT = new DataTable();

            SDA.SelectCommand = cmd;
            DT.Clear();
            SDA.Fill(DT);

            dataGridView1.DataSource = DT;

            con.Close();
        }


        //----------------------------------------------------------------------------------------------------------------------------------------


        //Update data
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            String bid = txtBookId.Text;
            String bname = txtBook.Text;
            String bauthor = txtAuthor.Text;
            String pub = txtPublisher.Text;
            String classi = comboBoxClass.Text;
            Int64 copies = Int64.Parse(txtCopies.Text);
            String status = comboBoxStatus.Text;


            if (MessageBox.Show("Data will be updated. Are you sure?", "Attention", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
            {
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                // Set the command text to update data from the Books table based on the retrieved book ID
                cmd.CommandText = "UPDATE Books SET bName = '" + bname +"', bAuthor = '" + bauthor + "', bPublisher = '" + pub +"', bClassification = '" + classi +"', bCopies = " + copies +", bStatus = '" + status +"' WHERE bId = '" + bid +"'";
                SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
                DataSet DS = new DataSet();
                SDA.Fill(DS);

                con.Close();

                MessageBox.Show("Data updated successfully!");

                txtBookId.Clear();
                txtBook.Clear();
                txtAuthor.Clear();
                txtPublisher.Clear();
                comboBoxClass.SelectedIndex = -1;
                txtCopies.Clear();
                comboBoxStatus.SelectedIndex = -1;
            }
        }

        
        //-----------------------------------------------------------------------------------------------------------------------------------------------


        //Delete data
        private void btnDelete_Click(object sender, EventArgs e)
        {
            String bid = txtBookId.Text;
            String bname = txtBook.Text;
            String bauthor = txtAuthor.Text;
            String pub = txtPublisher.Text;
            String classi = comboBoxClass.Text;
            Int64 copies = Int64.Parse(txtCopies.Text);
            String status = comboBoxStatus.Text;

            if (MessageBox.Show("Data will deleted. Are you sure?", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                con.Open();

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;

                // Set the command text to update data from the Books table based on the retrieved book ID
                cmd.CommandText = "DELETE FROM Books WHERE bId = '" + bid + "'";
                SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
                DataSet DS = new DataSet();
                SDA.Fill(DS);

                con.Close();

                frmBookView_Load(this, null);

                MessageBox.Show("Data deleted successfully!");

                txtBookId.Clear();
                txtBook.Clear();
                txtAuthor.Clear();
                txtPublisher.Clear();
                comboBoxClass.SelectedIndex = -1;
                txtCopies.Clear();
                comboBoxStatus.SelectedIndex = -1;
            }
        }


        //---------------------------------------------------------------------------------------------------------------------------------------------


        //Refresh form
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            frmBookView_Load(this, null);   //Refresh form

        }
    }
}

