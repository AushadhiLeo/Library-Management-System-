﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace Library_Management_System
{
    public partial class frmIssueBook : Form
    {
        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();

        //-------------------------------------------------------------------------------------------------------------------------------------------------


        // Dictionary to store book names and their corresponding IDs
        Dictionary<string, string> bookDictionary = new Dictionary<string, string>();


        //-------------------------------------------------------------------------------------------------------------------------------------------------

        public frmIssueBook()
        {
            InitializeComponent();
        }

        //-------------------------------------------------------------------------------------------------------------------------------------------------


        //Mouse hover colors
        private void btnRefresh_MouseEnter(object sender, EventArgs e)
        {
            btnRefresh.BackColor = Color.White;
        }

        private void btnRefresh_MouseLeave(object sender, EventArgs e) 
        {
            btnRefresh.BackColor = Color.WhiteSmoke;     //Refresh button
        }

        //*************************************************************************

        private void btnExit_MouseEnter(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Red;
        }

        private void btnExit_MouseLeave(object sender, EventArgs e) 
        {
            btnExit.BackColor = Color.FromArgb(192, 0, 0);  //Exit button
        }

        //*************************************************************************

        private void btnIssueBook_MouseEnter(object sender, EventArgs e)
        {
            btnIssueBook.BackColor = Color.Orange;
        }

        private void btnIssueBook_MouseLeave(object sender, EventArgs e)
        {
            btnIssueBook.BackColor = Color.DarkOrange;  //Issue Book Button
        }

        //*************************************************************************

        private void btnSearch_MouseEnter(object sender, EventArgs e)
        {
            btnSearch.BackColor = Color.Yellow;
        }

        private void btnSearch_MouseLeave(object sender, EventArgs e)
        {
            btnSearch.BackColor = Color.Gold;   //Search Button
        }


        //-----------------------------------------------------------------------------------------------------------------------------------------------

        //Close the form
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //-----------------------------------------------------------------------------------------------------------------------------------------------


        //Refresh form
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.Controls.Clear();
            this.InitializeComponent();  
        }

        //--------------------------------------------------------------------------------------------------------------------------------------------------------------



        //Connect book details to Book ID textbox and combobox
        private void frmIssueBook_Load(object sender, EventArgs e)
        {

            con.Open();


            SqlCommand cmd = new SqlCommand("SELECT bId, bName FROM Books WHERE bstatus = 'Borrowable'", con);   // SQL command to select book IDs and names from the Books table
            SqlDataReader DR = cmd.ExecuteReader();

            while (DR.Read())   // Read data from the database
            {
                string bookId = DR.GetString(0);
                string bookName = DR.GetString(1);  // Retrieve the book ID and name

                bookDictionary[bookName] = bookId;  // Store book ID and name in the dictionary
                                                
                comboBoxBook.Items.Add(bookName);   // Add book name to the combo box
            }
            DR.Close();

            con.Close();

            // Attach the SelectedIndexChanged event handler
            comboBoxBook.SelectedIndexChanged += new EventHandler(comboBoxBook_SelectedIndexChanged);
        }



        //--------------------------------------------------------------------------------------------------------------------------------------------------------------



        // Get the book ID from the dictionary and set it to the textbox
        private void comboBoxBook_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if an item is selected in the combo box
            if (comboBoxBook.SelectedItem != null)
            {
                string selectedBook = comboBoxBook.SelectedItem.ToString();

                // Check if the dictionary is initialized and contains the selected book
                if (bookDictionary != null && bookDictionary.TryGetValue(selectedBook, out string bookId))
                {
                    txtBId.Text = bookId;   // Display the Book Id
                }
                else
                {
                    // Optionally handle the case where the book is not found in the dictionary
                    txtBId.Text = string.Empty; // Clear the text box or handle accordingly
                }
            }
            else
            {
                // Optionally handle the case where no item is selected
                txtBId.Text = string.Empty; // Clear the text box or handle accordingly
            }
        }



        //--------------------------------------------------------------------------------------------------------------------------------------------------------------



        //Connect user details to textboxes according to userId
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if(txtSearch.Text != "")
            {
                string uid = txtSearch.Text;
                    
                con.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM Users WHERE uId = '" + uid +"'", con);   // SQL command to select data from the Users table
                SqlDataAdapter SDA = new SqlDataAdapter(cmd);   // Create a data adapter to execute the command and fill the dataset
                DataSet DS = new DataSet();
                SDA.Fill(DS);
               
                if (DS.Tables[0].Rows.Count != 0)   //Checks if the table has any data
                {
                    txtUname.Text = DS.Tables[0].Rows[0][1].ToString(); 
                    txtSex.Text = DS.Tables[0].Rows[0][2].ToString();
                    txtNIC.Text = DS.Tables[0].Rows[0][3].ToString();
                    txtAddress.Text = DS.Tables[0].Rows[0][4].ToString();
                }
                else
                {
                    txtUname.Clear();
                    txtSex.Clear();
                    txtNIC.Clear();
                    txtAddress.Clear();

                    MessageBox.Show("Invalid User Id","Error",MessageBoxButtons.OK, MessageBoxIcon.Error);  //Display error message if the userId is wrong/ not available                
                }

                con.Close();

            }
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------------------------

       
        //Issue books
        private void btnIssueBook_Click(object sender, EventArgs e)
        {
            string uid = txtSearch.Text;
            string uname = txtUname.Text;
            string sex = txtSex.Text;
            string nic = txtNIC.Text;
            string address = txtAddress.Text;
            string bid = txtBId.Text;
            string bname = comboBoxBook.Text;
            string issue = dateTimePickerIssue.Text;
            string due = dateTimePickerDue.Text;
            
            con.Open();

            //Checks how many books are currently issued to the user
            SqlCommand checkBooksCmd = new SqlCommand("SELECT COUNT(*) FROM Issue_Books WHERE UserId = '" + uid + "'", con);
            int bookCount = (int)checkBooksCmd.ExecuteScalar();

            if (bookCount >= 5)  //Checks if the user book count = or > 5 
            {
                MessageBox.Show("User already issued maximum of 5 books!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//Display error message if the book count > 5
                return;
            }

            con.Close();

            //********************************************************************************************************************


            con.Open();
            // Check if the user has already issued the same book
            SqlCommand checkSameBookCmd = new SqlCommand("SELECT COUNT(*) FROM Issue_Books WHERE UserId = '" + uid + "' AND BookId = '" + bid + "'", con);

            int sameBookCount = (int)checkSameBookCmd.ExecuteScalar();

            if (sameBookCount > 0) // Check if the same book is already issued to the user
            {
                MessageBox.Show("This book has already been issued to the user!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); // Display error message if the same book is already issued
                return;
            }
            
            con.Close();

            //********************************************************************************************************************
            
            con.Open();

            //Checks if have enough copies of books 
            SqlCommand checkCopiesCmd = new SqlCommand("SELECT bCopies FROM Books WHERE bId = '" + bid +"'", con);
            int checkCopies = (int)checkCopiesCmd.ExecuteScalar();

            if (checkCopies <= 0)  //Checks if the book copies count = 0
            {
                MessageBox.Show("Selected book haven't enough copies to issue!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);//Display error message if the book count < 5
                return;
            }

            con.Close();

            //********************************************************************************************************************


            con.Open();

            // Insert the new book issuance record
            SqlCommand insertQuery = new SqlCommand("INSERT INTO Issue_Books (UserId, UserName, Sex, UserNIC, UserAddress, BookId, BookName, IssueDate, DueDate) VALUES ('" + uid + "', '" + uname + "', '" + sex + "', '" + nic + "', '" + address + "', '" + bid + "', '" + bname + "', '" + issue + "', '" + due + "') ", con);
            insertQuery.ExecuteNonQuery();

            MessageBox.Show("Book issued successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            txtSearch.Clear();
            txtUname.Clear();
            txtSex.Clear();
            txtNIC.Clear();
            txtAddress.Clear();
            txtBId.Clear();
            comboBoxBook.SelectedIndex = -1;

            con.Close() ;

            //********************************************************************************************************************


            con.Open();

            // Update the quantity of the book in the Books table
            SqlCommand updateBookCmd = new SqlCommand("UPDATE Books SET bCopies = bCopies - 1 WHERE bId = '" + bid + "'", con); // decreases the number of available bCopies of the book by 1
            updateBookCmd.ExecuteNonQuery();


            con.Close();
        }
    }
}
