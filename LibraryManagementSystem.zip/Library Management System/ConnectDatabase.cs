﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library_Management_System
{
    internal class ConnectDatabase
    {
        //Establish a connection to a SQL database
        public SqlConnection connectToSQLDB()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-DLOVLD1\\SQLEXPRESS;Initial Catalog=FinalProject;Integrated Security=True"); //specifies the data source, initial catalog (database name), and integrated security settings for connecting to the SQL Server instance
            return conn;
        }
    }
}
