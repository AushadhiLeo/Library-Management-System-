﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library_Management_System
{
    public partial class frmUserReg : Form
    {
        //Connect ConnectDatabase class
        SqlConnection con = new ConnectDatabase().connectToSQLDB();

        //-------------------------------------------------------------------------------------------------------------------------------------------------

        public frmUserReg()
        {
            InitializeComponent();
            userId();
        }

        //---------------------------------------------------------------------------------------------------------------------------------------------

        //Mouse hover colors       
        private void btnAdd_MouseEnter(object sender, EventArgs e)
        {
            btnAdd.BackColor = Color.FromArgb(0, 192, 0);
        }
               
        private void btnAdd_MouseLeave(object sender, EventArgs e)  //ADD USER button colors
        {
            btnAdd.BackColor = Color.Green;
        }

        private void btnExit_MouseEnter_1(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.Red;
        }

        private void btnExit_MouseLeave_1(object sender, EventArgs e)
        {
            btnExit.BackColor = Color.FromArgb(192, 0, 0);  //Exit button
        }

        //-------------------------------------------------------------------------------------------------------------------------------------------

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();   //Close the form
        }


        //--------------------------------------------------------------------------------------------------------------------------------------------


        //Generate the UserId
       
        SqlCommand cmd;
        SqlDataAdapter da;  // Define class-level variables for SQL operations
        SqlDataReader dr;
        string sql;

        public void userId()    // Method to generate a new user ID
        {
            try
            {                
                sql = "SELECT MAX(uId) FROM Users";  // get the maximum user ID from the Users table
                cmd = new SqlCommand(sql, con); // Initialize the SqlCommand with the query and connection

                con.Open();

                var maxid = cmd.ExecuteScalar() as string;  // Execute the query and get the result as a string

                if (maxid == null)  // Check if the result is null
                {
                    txtUserID.Text = "U0001";    // If no records, set the user ID to the starting value "U0001"
                }
                else
                {
                    int intval = int.Parse(maxid.Substring(1, 4));  // Extract the numeric part from the max ID ( "U0001" -> 1)
                    intval++;   // Increment the numeric part by 1
                    txtUserID.Text = String.Format("U{0:0000}", intval);     // Format the new user ID with a leading "U" and padded zeros
                }

                con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);    // Display any exceptions that occur in a message box
            }
        }



        //---------------------------------------------------------------------------------------------------------------------------------------------


        //Add new user
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string uid = txtUserID.Text;
            string uname = txtUserName.Text;
            string sex = comboBoxSex.Text;
            string nic = txtNIC.Text;
            string address = txtAddress.Text;

            con.Open();

            // Insert Query - Insert data into columns from Users table
            SqlCommand cmd = new SqlCommand("INSERT INTO Users(uId, uName, uSex, uNIC, uAddress) VALUES ('" + uid + "', '" + uname + "','" + sex + "','" + nic + "','" + address + "')", con);
            cmd.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("New user added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            userId();   // Call the userId() function to generate a new user ID

            // Clear the textboxes and reset the combo box after successful insertion
            txtUserName.Clear();
            comboBoxSex.SelectedIndex = -1; // Reset to default value
            txtNIC.Clear();
            txtAddress.Clear();

        }
    }
}
